package com.dragonbar.client.render;

import com.dragonbar.DragonBarMod;
import com.dragonbar.entity.InfernalBoxeEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

/**
 * Infernal BoxE: las varas (upperBodyParts5..11) estan todas apiladas en el centro del modelo,
 * asi que aqui se reparten en un anillo que gira (como las varas del Blaze).
 */
public class InfernalModel extends GeoModel<InfernalBoxeEntity> {
    private static final Identifier GEO  = Identifier.of(DragonBarMod.MOD_ID, "geo/infernus_draco.geo.json");
    private static final Identifier TEX  = Identifier.of(DragonBarMod.MOD_ID, "textures/entity/infernus_draco.png");
    private static final Identifier ANIM = Identifier.of(DragonBarMod.MOD_ID, "animations/infernus_draco.animation.json");

    private static final int   ROD_FIRST = 5, ROD_LAST = 11;
    private static final float RING_RADIUS = 8f;   // pixeles del modelo

    @Override public Identifier getModelResource(InfernalBoxeEntity a)     { return GEO; }
    @Override public Identifier getTextureResource(InfernalBoxeEntity a)   { return TEX; }
    @Override public Identifier getAnimationResource(InfernalBoxeEntity a) { return ANIM; }

    @Override
    public void setCustomAnimations(InfernalBoxeEntity e, long instanceId, AnimationState<InfernalBoxeEntity> state) {
        float pt = state.getPartialTick();
        float t = e.age + pt;
        float spin = MathHelper.lerp(pt, e.spinO, e.spin);

        int n = ROD_LAST - ROD_FIRST + 1;
        for (int k = 0; k < n; k++) {
            var bone = getAnimationProcessor().getBone("upperBodyParts" + (ROD_FIRST + k));
            if (bone == null) continue;
            float a = spin + k * MathHelper.TAU / n;
            bone.setPosX(MathHelper.cos(a) * RING_RADIUS);
            bone.setPosZ(MathHelper.sin(a) * RING_RADIUS);
            bone.setPosY(MathHelper.sin(t * 0.12f + k) * 1.5f);
        }

        // Alas: suben y bajan
        var wings = getAnimationProcessor().getBone("upperBodyParts4");
        if (wings != null) wings.setPosY(MathHelper.sin(t * 0.3f) * 1.2f);

        // Cabeza sigue la mirada
        var head = getAnimationProcessor().getBone("head");
        EntityModelData data = state.getData(DataTickets.ENTITY_MODEL_DATA);
        if (head != null && data != null) {
            head.setRotX(data.headPitch() * MathHelper.RADIANS_PER_DEGREE);
            head.setRotY(data.netHeadYaw() * MathHelper.RADIANS_PER_DEGREE);
        }
    }
}
