package com.dragonbar.client.render;

import com.dragonbar.entity.InfernalBoxeEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class InfernalRenderer extends GeoEntityRenderer<InfernalBoxeEntity> {
    public InfernalRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new InfernalModel());
        this.shadowRadius = 0.4f;
    }
}
