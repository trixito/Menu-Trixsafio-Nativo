package com.dragonbar.client.render;

import com.dragonbar.entity.DrakilEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class DrakilRenderer extends GeoEntityRenderer<DrakilEntity> {
    public DrakilRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new DrakilModel());
        this.shadowRadius = 0.5f;
    }
}
