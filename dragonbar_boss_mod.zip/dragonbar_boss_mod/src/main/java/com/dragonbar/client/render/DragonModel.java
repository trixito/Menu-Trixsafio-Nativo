package com.dragonbar.client.render;

import com.dragonbar.DragonBarMod;
import com.dragonbar.entity.DragonBossEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;

/**
 * Todo el movimiento del dragon se hace por codigo: aqui se rotan los huesos
 * cada frame segun el estado que sincroniza el servidor (ver DragonBossEntity).
 *
 * Convencion usada: en huesos que miran a -Z, rotX positivo = la punta baja.
 * Si algun giro se ve invertido en el juego, cambia los signos de las constantes de abajo.
 */
public class DragonModel extends GeoModel<DragonBossEntity> {
    private static final Identifier GEO  = Identifier.of(DragonBarMod.MOD_ID, "geo/dragon_oriental.geo.json");
    private static final Identifier TEX  = Identifier.of(DragonBarMod.MOD_ID, "textures/entity/dragon_oriental.png");
    private static final Identifier ANIM = Identifier.of(DragonBarMod.MOD_ID, "animations/dragon_oriental.animation.json");

    // ---- signos / ajustes rapidos ----
    private static final float CURL_SIGN  = 1f;    // curvatura del cuerpo al girar
    private static final float PITCH_SIGN = 1f;    // inclinacion de todo el dragon (picada)
    private static final float WAVE_SPEED = 0.22f; // velocidad de la ondulacion
    private static final float WAVE_AMP   = 0.13f; // amplitud base de la ondulacion (rad)

    private static final String[] CHAIN = {
            "body_1", "body_2", "body_3", "body_4", "body_5", "body_6", "body_7",
            "tail_1", "tail_2", "tail_3", "tail_tip"
    };

    @Override public Identifier getModelResource(DragonBossEntity a)     { return GEO; }
    @Override public Identifier getTextureResource(DragonBossEntity a)   { return TEX; }
    @Override public Identifier getAnimationResource(DragonBossEntity a) { return ANIM; }

    private void rot(String name, float x, float y, float z) {
        var bone = getAnimationProcessor().getBone(name);
        if (bone != null) {
            bone.setRotX(x);
            bone.setRotY(y);
            bone.setRotZ(z);
        }
    }

    @Override
    public void setCustomAnimations(DragonBossEntity e, long instanceId, AnimationState<DragonBossEntity> state) {
        float pt = state.getPartialTick();
        float t = e.age + pt;

        float open  = MathHelper.lerp(pt, e.openAmtO,  e.openAmt);   // 0..1 cabeza arriba + boca abierta
        float lower = MathHelper.lerp(pt, e.lowerAmtO, e.lowerAmt);  // 0..1 cabeza baja (embestida/picada)
        float waveK = MathHelper.lerp(pt, e.waveAmtO,  e.waveAmt);   // multiplicador de ondulacion
        float curl  = MathHelper.lerp(pt, e.curlO,     e.curl);      // grados por segmento al girar
        float pitch = MathHelper.lerp(pt, e.pitchVO,   e.pitchV);    // grados, + = hacia abajo
        float speed = MathHelper.lerp(pt, e.speedO,    e.speed);     // bloques/tick

        float phase = t * WAVE_SPEED;
        float curlRad = curl * MathHelper.RADIANS_PER_DEGREE * CURL_SIGN;

        // Todo el dragon: pitch (picada / ascenso)
        rot("root", pitch * MathHelper.RADIANS_PER_DEGREE * PITCH_SIGN, 0f, 0f);

        // Cuerpo + cola: onda serpenteante + curvatura al girar (espiral)
        float firstSegY = 0f;
        for (int i = 0; i < CHAIN.length; i++) {
            float amp = WAVE_AMP * waveK * (0.5f + 0.1f * i);
            float y = MathHelper.sin(phase - i * 0.6f) * amp + curlRad;
            float x = MathHelper.sin(phase * 0.8f - i * 0.5f) * 0.035f * waveK;
            if (i == 0) firstSegY = y;
            rot(CHAIN[i], x, y, 0f);
        }

        // Cuello / cabeza / mandibula
        rot("neck", -0.15f * open + 0.25f * lower + MathHelper.sin(phase * 0.7f) * 0.02f,
                -firstSegY * 0.8f, 0f);
        rot("head", -0.45f * open + 0.35f * lower, 0f, 0f);
        rot("jaw", 0.6f * open + 0.04f * MathHelper.sin(t * 0.4f), 0f, 0f);
        rot("mane", MathHelper.sin(phase * 1.3f) * 0.08f, 0f, 0f);

        // Bigotes: se echan hacia atras con la velocidad y ondulan
        float trail = 0.35f + MathHelper.clamp(speed * 0.8f, 0f, 0.8f);
        float sway = MathHelper.sin(phase * 1.1f);
        float swayTip = MathHelper.sin(phase * 1.1f - 1.0f);
        rot("whisker_l",     trail + MathHelper.sin(phase - 0.5f) * 0.12f,  0.15f + sway * 0.2f, 0f);
        rot("whisker_l_tip", 0.2f + MathHelper.sin(phase - 0.9f) * 0.15f,   swayTip * 0.35f, 0f);
        rot("whisker_r",     trail + MathHelper.sin(phase - 0.5f) * 0.12f, -0.15f + sway * 0.2f, 0f);
        rot("whisker_r_tip", 0.2f + MathHelper.sin(phase - 0.9f) * 0.15f,   swayTip * 0.35f, 0f);

        // Patas recogidas hacia atras mientras vuela
        float tuck = 0.8f + 0.3f * lower + 0.2f * open;
        float flutter = MathHelper.sin(phase * 1.3f) * 0.08f;
        String[] legs = {"leg_fl", "leg_fr", "leg_bl", "leg_br"};
        for (int i = 0; i < legs.length; i++) {
            float f = flutter * ((i % 2 == 0) ? 1f : -1f);
            rot(legs[i] + "_upper", tuck + f, 0f, 0f);
            rot(legs[i] + "_lower", tuck * 0.7f - f, 0f, 0f);
            rot(legs[i] + "_foot", 0.2f + f * 0.5f, 0f, 0f);
        }
    }
}
