package com.dragonbar.client.render;

import com.dragonbar.DragonBarMod;
import com.dragonbar.entity.DrakilEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

/**
 * Drakil: sin animaciones .json. Caminar, golpe, vuelo (ala aleteando) y cabeza, todo por codigo.
 * Si algo se ve al reves, cambia los signos de abajo.
 */
public class DrakilModel extends GeoModel<DrakilEntity> {
    private static final Identifier GEO  = Identifier.of(DragonBarMod.MOD_ID, "geo/drakil.geo.json");
    private static final Identifier TEX  = Identifier.of(DragonBarMod.MOD_ID, "textures/entity/drakil.png");
    private static final Identifier ANIM = Identifier.of(DragonBarMod.MOD_ID, "animations/drakil.animation.json");

    private static final float ARM_RAISE_SIGN = -1f;  // sentido en que los brazos suben al atacar
    private static final float LEAN_SIGN      = 1f;   // inclinacion hacia adelante al volar

    @Override public Identifier getModelResource(DrakilEntity a)     { return GEO; }
    @Override public Identifier getTextureResource(DrakilEntity a)   { return TEX; }
    @Override public Identifier getAnimationResource(DrakilEntity a) { return ANIM; }

    private CoreGeoBone bone(String n) { return getAnimationProcessor().getBone(n); }

    /** Rotacion = pose original del modelo + delta (los huesos con rotacion de Blockbench la conservan). */
    private void rotAdd(String name, float dx, float dy, float dz) {
        CoreGeoBone b = bone(name);
        if (b == null) return;
        var init = b.getInitialSnapshot();
        b.setRotX(init.getRotX() + dx);
        b.setRotY(init.getRotY() + dy);
        b.setRotZ(init.getRotZ() + dz);
    }

    @Override
    public void setCustomAnimations(DrakilEntity e, long instanceId, AnimationState<DrakilEntity> state) {
        float pt = state.getPartialTick();
        float t = e.age + pt;
        float fly = MathHelper.lerp(pt, e.flyAmtO, e.flyAmt);
        float swing = state.getLimbSwing();
        float amount = state.getLimbSwingAmount();
        float attack = e.getHandSwingProgress(pt);
        float atk = MathHelper.sin(attack * MathHelper.PI) * 1.9f * ARM_RAISE_SIGN;

        // Piernas: caminan en el suelo, se recogen al volar
        float walk = MathHelper.cos(swing * 0.6662f) * 1.3f * amount * (1f - fly);
        rotAdd("leftLeg",  walk + 0.5f * fly, 0f, 0f);
        rotAdd("rightLeg", -walk + 0.5f * fly, 0f, 0f);

        // Brazos: balanceo opuesto + tajo al atacar
        float armWalk = MathHelper.cos(swing * 0.6662f) * 1.0f * amount * (1f - fly);
        float idle = MathHelper.sin(t * 0.09f) * 0.05f;
        rotAdd("leftArm",  -armWalk + atk + idle + 0.3f * fly * ARM_RAISE_SIGN, 0f, 0.05f);
        rotAdd("rightArm",  armWalk + atk - idle + 0.3f * fly * ARM_RAISE_SIGN, 0f, -0.05f);

        // Ala: aleteo al volar, plegada en el suelo
        float flap = MathHelper.sin(t * 0.55f) * 0.9f * fly + MathHelper.sin(t * 0.1f) * 0.05f;
        rotAdd("ala", 0f, 0.15f * fly * MathHelper.sin(t * 0.55f), flap);

        // Todo el cuerpo se inclina al volar
        rotAdd("root", 0.3f * fly * LEAN_SIGN, 0f, 0f);

        // Cabeza sigue la mirada
        EntityModelData data = state.getData(DataTickets.ENTITY_MODEL_DATA);
        float hx = 0f, hy = 0f;
        if (data != null) {
            hx = data.headPitch() * MathHelper.RADIANS_PER_DEGREE;
            hy = data.netHeadYaw() * MathHelper.RADIANS_PER_DEGREE;
        }
        rotAdd("head", hx, hy, 0f);
        rotAdd("cara", hx, hy, 0f);
    }
}
