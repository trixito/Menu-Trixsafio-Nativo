package com.dragonbar.client;

import com.dragonbar.client.render.DragonRenderer;
import com.dragonbar.client.render.DrakilRenderer;
import com.dragonbar.client.render.InfernalRenderer;
import com.dragonbar.entity.InfernalFireballEntity;
import com.dragonbar.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public class DragonBarClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.DRAGON_ORIENTAL, DragonRenderer::new);
        EntityRendererRegistry.register(ModEntities.DRAKIL, DrakilRenderer::new);
        EntityRendererRegistry.register(ModEntities.INFERNAL_BOXE, InfernalRenderer::new);
        // Bola de fuego: sprite de fire charge, grande y brillante
        EntityRendererRegistry.register(ModEntities.INFERNAL_FIREBALL,
                ctx -> new FlyingItemEntityRenderer<InfernalFireballEntity>(ctx, 3.0f, true));
    }
}
