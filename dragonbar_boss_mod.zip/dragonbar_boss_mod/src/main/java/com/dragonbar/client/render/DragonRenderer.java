package com.dragonbar.client.render;

import com.dragonbar.entity.DragonBossEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class DragonRenderer extends GeoEntityRenderer<DragonBossEntity> {
    /** Escala visual del modelo (el hitbox se define en ModEntities). */
    public static final float MODEL_SCALE = 1.5f;

    public DragonRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new DragonModel());
        // Lee automaticamente textures/entity/dragon_oriental_glowmask.png
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        withScale(MODEL_SCALE);
        this.shadowRadius = 1.8f;
    }
}
