package com.dragonbar.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Bola de fuego del Infernal BoxE: quema y empuja de forma absurda. No rompe ni incendia bloques. */
public class InfernalFireballEntity extends SmallFireballEntity {
    public static final float  DAMAGE       = 5.0f;
    public static final int    BURN_SECONDS = 8;
    public static final double KNOCKBACK    = 4.2;   // horizontal (absurdo)
    public static final double KNOCKBACK_Y  = 1.15;
    private static final int   MAX_AGE      = 120;

    public InfernalFireballEntity(EntityType<? extends InfernalFireballEntity> type, World world) {
        super(type, world);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 2, 0.1, 0.1, 0.1, 0.01);
            if (age > MAX_AGE) discard();
        }
    }

    @Override
    protected boolean canHit(Entity entity) {
        if (entity instanceof DrakilEntity || entity instanceof InfernalBoxeEntity || entity instanceof DragonBossEntity) {
            return false; // no le pega a sus aliados
        }
        return super.canHit(entity);
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        if (getWorld().isClient) return;
        Entity target = hit.getEntity();
        Entity owner = getOwner();

        target.damage(getDamageSources().fireball(this, owner), DAMAGE);
        target.setOnFireFor(BURN_SECONDS);

        Vec3d v = getVelocity();
        Vec3d h = new Vec3d(v.x, 0, v.z);
        h = h.lengthSquared() < 1.0E-4 ? Vec3d.ZERO : h.normalize();
        if (target instanceof LivingEntity) {
            target.setVelocity(h.x * KNOCKBACK, KNOCKBACK_Y, h.z * KNOCKBACK);
            target.velocityModified = true;
        }
        impactFx();
        discard();
    }

    @Override
    protected void onBlockHit(BlockHitResult hit) {
        if (getWorld().isClient) return;
        impactFx();
        discard();
    }

    private void impactFx() {
        if (getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 25, 0.4, 0.4, 0.4, 0.08);
            sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 6, 0.3, 0.3, 0.3, 0.02);
            sw.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 0.8f, 1.3f);
        }
    }
}
