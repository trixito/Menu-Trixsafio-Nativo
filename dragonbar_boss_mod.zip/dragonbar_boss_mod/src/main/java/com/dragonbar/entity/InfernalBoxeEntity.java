package com.dragonbar.entity;

import com.dragonbar.registry.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;

/**
 * Infernal BoxE: esbirro volador tipo Blaze. Orbita al jugador y le dispara bolas de fuego
 * con empuje exagerado que ademas queman (ver InfernalFireballEntity).
 */
public class InfernalBoxeEntity extends HostileEntity implements GeoEntity {
    // ---- balance ----
    private static final double FIREBALL_SPEED = 1.1;
    private static final double ORBIT_RADIUS   = 11.0;
    private static final double ORBIT_HEIGHT   = 4.5;
    private static final int    SHOOT_CD_MIN   = 55;
    private static final int    SHOOT_CD_RAND  = 25;
    private static final int    WINDUP_TICKS   = 15;

    private static final TrackedData<Boolean> CHARGING =
            DataTracker.registerData(InfernalBoxeEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    /** Fase de giro de las varas (cliente, lo lee InfernalModel). */
    public float spin, spinO;

    public InfernalBoxeEntity(EntityType<? extends InfernalBoxeEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 20, true);
        this.experiencePoints = 12;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.5)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0)
                .add(EntityAttributes.GENERIC_ARMOR, 2.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(CHARGING, false);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(1, new HoverShootGoal(this));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    public boolean isCharging() { return dataTracker.get(CHARGING); }
    private void setCharging(boolean b) { if (isCharging() != b) dataTracker.set(CHARGING, b); }

    @Override
    public void tickMovement() {
        if (getWorld().isClient) {
            spinO = spin;
            spin += isCharging() ? 0.35f : 0.12f;
            if (isCharging() && random.nextInt(2) == 0) {
                Vec3d m = getEyePos().add(getRotationVec(1.0f).multiply(0.8));
                getWorld().addParticle(ParticleTypes.FLAME, m.x, m.y, m.z, 0, 0.02, 0);
            }
        }
        super.tickMovement();
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_BLAZE_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_BLAZE_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_BLAZE_DEATH; }

    // ---- GeckoLib (el movimiento de varas se hace por codigo en InfernalModel) ----
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) { }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return geoCache; }

    private void shootFireball(LivingEntity target, double yawOffset) {
        Vec3d from = getEyePos().add(0, -0.2, 0);
        Vec3d to = target.getPos().add(0, target.getHeight() * 0.5, 0);
        Vec3d dir = to.subtract(from).normalize().rotateY((float) yawOffset);

        InfernalFireballEntity f = new InfernalFireballEntity(ModEntities.INFERNAL_FIREBALL, getWorld());
        f.setOwner(this);
        f.setPosition(from.add(dir.multiply(1.2)));
        f.setVelocity(dir.multiply(FIREBALL_SPEED));
        getWorld().spawnEntity(f);
    }

    /** Orbita al objetivo a cierta altura, carga y dispara. */
    private static class HoverShootGoal extends Goal {
        private final InfernalBoxeEntity mob;
        private int shootCd = 40;
        private double angle;
        private int dir = 1;

        HoverShootGoal(InfernalBoxeEntity mob) {
            this.mob = mob;
            setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override public boolean canStart() {
            LivingEntity t = mob.getTarget();
            return t != null && t.isAlive();
        }

        @Override public void start() {
            shootCd = 40 + mob.random.nextInt(30);
            angle = mob.random.nextDouble() * Math.PI * 2;
            dir = mob.random.nextBoolean() ? 1 : -1;
        }

        @Override public void stop() { mob.setCharging(false); }

        @Override public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) return;
            mob.getLookControl().lookAt(t, 30.0f, 30.0f);

            angle += 0.035 * dir;
            double gx = t.getX() + Math.cos(angle) * ORBIT_RADIUS;
            double gz = t.getZ() + Math.sin(angle) * ORBIT_RADIUS;
            double gy = t.getY() + ORBIT_HEIGHT + Math.sin(mob.age * 0.1) * 1.0;
            mob.getMoveControl().moveTo(gx, gy, gz, 1.0);

            boolean sees = mob.getVisibilityCache().canSee(t);
            if (shootCd > 0) shootCd--;
            mob.setCharging(sees && shootCd <= WINDUP_TICKS);

            if (shootCd <= 0 && sees) {
                boolean hurt = mob.getHealth() < mob.getMaxHealth() * 0.5f;
                mob.shootFireball(t, 0.0);
                if (hurt) { mob.shootFireball(t, 0.18); mob.shootFireball(t, -0.18); }
                mob.getWorld().playSound(null, mob.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT,
                        SoundCategory.HOSTILE, 1.2f, 0.8f);
                shootCd = SHOOT_CD_MIN + mob.random.nextInt(SHOOT_CD_RAND);
            }
        }
    }
}
