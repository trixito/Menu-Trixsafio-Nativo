package com.dragonbar.entity;

import com.dragonbar.registry.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.BodyControl;
import net.minecraft.entity.ai.control.LookControl;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.UUID;
import java.util.Iterator;
import java.util.List;

/**
 * Omega Wyvern (antes Dragon Oriental) - primer boss de Trixsafio.
 *
 * Toda la IA es una maquina de estados en el servidor (mobTick). El estado y la
 * inclinacion se sincronizan con el cliente por DataTracker y DragonModel rota los
 * huesos por codigo (no hay animaciones .json).
 *
 * Ataques:
 *  - FIRE   : rafaga de fuego (lanzallamas en cono que quema a los jugadores)
 *  - SPIRAL : sube en espiral, caen rayos + levitacion; luego DIVE (picada) con onda de impacto
 *  - CHARGE : furia embestida contra un jugador con knockback gigante
 */
public class DragonBossEntity extends PathAwareEntity implements GeoEntity {

    // =====================================================================
    //  AJUSTES (balance rapido)
    // =====================================================================
    // Fuego
    private static final int    FIRE_WINDUP        = 20;
    private static final int    FIRE_DURATION      = 90;
    private static final double FIRE_RANGE         = 26.0;
    private static final double FIRE_CONE_COS      = 0.88;   // ~28 grados
    private static final float  FIRE_DAMAGE        = 3.5f;   // cada 5 ticks
    private static final int    FIRE_BURN_SECONDS  = 10;
    private static final double FIRE_DISTANCE      = 17.0;   // distancia horizontal al objetivo
    private static final double FIRE_HEIGHT        = 8.0;    // altura sobre el objetivo
    // Espiral / rayos
    private static final double SPIRAL_RADIUS      = 9.0;
    private static final double SPIRAL_HEIGHT      = 26.0;
    private static final double SPIRAL_ANG_SPEED   = 0.16;   // rad/tick
    private static final int    SPIRAL_TICKS       = 125;
    private static final int    LIGHTNING_INTERVAL = 12;     // ticks entre rayos (antes 7)
    private static final int    LIGHTNING_TELEGRAPH = 9;     // ticks de aviso (chispas) antes del rayo
    private static final double LIGHTNING_EFFECT_RADIUS = 6.0;
    private static final int    LEVITATION_TICKS   = 130;
    private static final int    LEVITATION_AMP     = 2;
    // Picada / impacto
    private static final int    DIVE_HANG          = 14;     // ticks de pausa apuntando hacia abajo
    private static final double SLAM_RADIUS        = 20.0;
    private static final float  SLAM_DAMAGE_MIN    = 14.0f;  // en el borde (20 bloques)
    private static final float  SLAM_DAMAGE_MAX    = 40.0f;  // en el centro
    // Embestida
    private static final int    CHARGE_WINDUP      = 26;
    private static final int    CHARGE_MAX_TICKS   = 45;
    private static final double CHARGE_SPEED       = 2.6;
    private static final float  CHARGE_DAMAGE      = 26.0f;
    private static final double CHARGE_KNOCKBACK   = 3.2;    // horizontal (gigante)
    private static final double CHARGE_KNOCKBACK_Y = 0.9;

    // Esbirros: [oleada 1, oleada 2]. Cada 3 jugadores cerca suma +1 de cada tipo.
    private static final int[] WAVE_DRAKIL   = { 2, 3 };
    private static final int[] WAVE_INFERNAL = { 1, 2 };
    private static final double MINION_RADIUS_MIN = 6.0, MINION_RADIUS_MAX = 12.0;

    // =====================================================================
    //  ESTADOS
    // =====================================================================
    public enum State { IDLE, FIRE, SPIRAL, DIVE, CHARGE_WINDUP, CHARGE_DASH, RECOVER, HELL_CHARGE, HELL_BEAM }

    private static final TrackedData<Integer> STATE =
            DataTracker.registerData(DragonBossEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Float> VIS_PITCH =
            DataTracker.registerData(DragonBossEntity.class, TrackedDataHandlerRegistry.FLOAT);

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bossBar = new ServerBossBar(
            Text.translatable("entity.dragonbar.dragon_oriental"),
            BossBar.Color.GREEN,           // GREEN => el mixin dragonbar le pone el dragon a la bossbar
            BossBar.Style.PROGRESS);

    // ---- servidor ----
    private int stateTicks;
    private int cooldown = 60;
    private int recoverTicks = 20;
    private State lastAttack = State.IDLE;
    private Vec3d spiralCenter = Vec3d.ZERO;
    private double spiralAngle, spiralStartY, spiralR0;
    private Vec3d diveTarget = Vec3d.ZERO;
    private Vec3d chargeDir = Vec3d.ZERO;
    private ServerPlayerEntity chargeTarget;
    private boolean chargeHit;
    private boolean summonedAt66, summonedAt33;
    private int pendingWaves, wavesSpawned;
    private final Set<UUID> minions = new HashSet<>();
    private final List<Strike> strikes = new ArrayList<>();

    private static final class Strike {
        final Vec3d pos;
        int left;
        Strike(Vec3d pos, int left) { this.pos = pos; this.left = left; }
    }

    // ---- cliente (animacion suave, lo lee DragonModel) ----
    public float openAmt, openAmtO, lowerAmt, lowerAmtO, waveAmt = 1f, waveAmtO = 1f;
    public float curl, curlO, pitchV, pitchVO, speed, speedO;

    public DragonBossEntity(EntityType<? extends DragonBossEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
        this.experiencePoints = 500;
        this.setPersistent();
        // Nosotros controlamos yaw/pitch: anulamos el LookControl vanilla (que resetea el pitch)
        this.lookControl = new LookControl(this) {
            @Override public void tick() { }
        };
    }

    @Override
    protected BodyControl createBodyControl() {
        return new BodyControl(this) {
            @Override
            public void tick() {
                DragonBossEntity.this.bodyYaw = DragonBossEntity.this.getYaw();
                DragonBossEntity.this.headYaw = DragonBossEntity.this.getYaw();
            }
        };
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 1500.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 18.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.5)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.8)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 80.0)
                .add(EntityAttributes.GENERIC_ARMOR, 12.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(STATE, 0);
        builder.add(VIS_PITCH, 0f);
    }

    // =====================================================================
    //  GeckoLib
    // =====================================================================
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Sin controladores: los huesos se mueven por codigo en DragonModel.setCustomAnimations
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    // =====================================================================
    //  Bossbar / vida / inmunidades
    // =====================================================================
    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }

    @Override
    public void setCustomName(Text name) {
        super.setCustomName(name);
        bossBar.setName(getDisplayName());
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        this.setNoGravity(false);
        bossBar.clearPlayers();
    }

    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        bossBar.clearPlayers();
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return super.isInvulnerableTo(source)
                || source.isOf(DamageTypes.IN_WALL)
                || source.isOf(DamageTypes.DROWN)
                || source.isOf(DamageTypes.FALL)
                || source.isOf(DamageTypes.LIGHTNING_BOLT)
                || source.isOf(DamageTypes.IN_FIRE)
                || source.isOf(DamageTypes.ON_FIRE);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    public void onStruckByLightning(ServerWorld world, LightningEntity lightning) {
        // Inmune a sus propios rayos
    }

    @Override
    public Box getVisibilityBoundingBox() {
        // El cuerpo mide ~12 bloques: ampliamos la caja de culling para que no desaparezca la cola
        return getBoundingBox().expand(14.0, 5.0, 14.0);
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_ENDER_DRAGON_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_ENDER_DRAGON_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_ENDER_DRAGON_DEATH; }
    @Override protected float getSoundVolume() { return 3.0f; }

    // =====================================================================
    //  Estado helpers
    // =====================================================================
    public State getState() {
        State[] v = State.values();
        return v[MathHelper.clamp(dataTracker.get(STATE), 0, v.length - 1)];
    }

    private void setState(State s) {
        dataTracker.set(STATE, s.ordinal());
        stateTicks = 0;
    }

    private boolean enraged() {
        return getHealth() < getMaxHealth() * 0.5f;
    }

    // =====================================================================
    //  tick: cliente (animacion) / servidor (IA)
    // =====================================================================
    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) clientAnimTick();
    }

    private void clientAnimTick() {
        openAmtO = openAmt; lowerAmtO = lowerAmt; waveAmtO = waveAmt;
        curlO = curl; pitchVO = pitchV; speedO = speed;

        float tOpen, tLower, tWave;
        switch (getState()) {
            case FIRE          -> { tOpen = 1.0f; tLower = 0.0f; tWave = 0.6f; }
            case SPIRAL        -> { tOpen = 0.4f; tLower = 0.0f; tWave = 0.3f; }
            case DIVE          -> { tOpen = 0.0f; tLower = 0.8f; tWave = 0.2f; }
            case CHARGE_WINDUP -> { tOpen = 0.8f; tLower = 0.0f; tWave = 1.4f; }
            case CHARGE_DASH   -> { tOpen = 0.3f; tLower = 1.0f; tWave = 0.5f; }
            case HELL_CHARGE   -> { tOpen = 1.0f; tLower = 0.0f; tWave = 0.4f; }
            case HELL_BEAM     -> { tOpen = 1.0f; tLower = 0.0f; tWave = 0.3f; }
            default            -> { tOpen = 0.0f; tLower = 0.0f; tWave = 1.0f; }
        }
        openAmt  += (tOpen  - openAmt)  * 0.2f;
        lowerAmt += (tLower - lowerAmt) * 0.2f;
        waveAmt  += (tWave  - waveAmt)  * 0.2f;

        double dx = getX() - prevX, dz = getZ() - prevZ;
        float hs = (float) Math.sqrt(dx * dx + dz * dz);
        speed += (hs - speed) * 0.3f;

        // curvatura del cuerpo = giro de yaw por bloque recorrido * largo de segmento (~0.94 bloques)
        float yawRate = MathHelper.wrapDegrees(getYaw() - prevYaw);
        float targetCurl = hs > 0.1f ? MathHelper.clamp(yawRate / hs * 0.94f, -25f, 25f) : 0f;
        curl += (targetCurl - curl) * 0.25f;

        pitchV += (dataTracker.get(VIS_PITCH) - pitchV) * 0.35f;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (!(getWorld() instanceof ServerWorld sw)) return;

        bossBar.setPercent(getHealth() / getMaxHealth());
        checkSummonThresholds(sw);
        tickStrikes(sw);
        tickInfernal(sw);

        PlayerEntity target = pickTarget();
        State s = getState();

        if (target == null) {
            // Nadie cerca: se queda flotando
            if (s != State.IDLE && s != State.RECOVER) setState(State.IDLE);
            setVelocity(getVelocity().multiply(0.85));
            aimBody(Vec3d.fromPolar(0f, getYaw()), 5f, 0.1f);
            return;
        }

        stateTicks++;
        switch (s) {
            case IDLE          -> tickIdle(sw, target);
            case FIRE          -> tickFire(sw, target);
            case SPIRAL        -> tickSpiral(sw);
            case DIVE          -> tickDive(sw);
            case CHARGE_WINDUP -> tickChargeWindup(sw);
            case CHARGE_DASH   -> tickChargeDash(sw);
            case RECOVER       -> tickRecover(sw, target);
            case HELL_CHARGE   -> tickHellCharge(sw);
            case HELL_BEAM     -> tickHellBeam(sw);
        }
    }

    // =====================================================================
    //  IDLE: orbita al objetivo y elige ataque
    // =====================================================================
    private void tickIdle(ServerWorld sw, PlayerEntity target) {
        double ang = age * 0.025;
        double r = 20.0;
        Vec3d goal = new Vec3d(target.getX() + Math.cos(ang) * r, target.getY() + 11.0, target.getZ() + Math.sin(ang) * r);
        double far = goal.distanceTo(getPos());
        steer(goal, far > 40 ? 1.6 : 0.9, 0.12);

        Vec3d v = getVelocity();
        Vec3d look = v.horizontalLengthSquared() > 0.01 ? v : target.getPos().subtract(getPos());
        aimBody(look, 8f, 0.12f);

        if (--cooldown <= 0) chooseAttack(sw, target);
    }

    /** Bolsa mezclada: salen los 4 ataques una vez cada uno antes de repetir (ninguno se queda sin salir). */
    private final List<State> attackBag = new ArrayList<>();

    private void chooseAttack(ServerWorld sw, PlayerEntity target) {
        if (attackBag.isEmpty()) {
            attackBag.addAll(List.of(State.FIRE, State.SPIRAL, State.CHARGE_WINDUP, State.HELL_CHARGE));
            Collections.shuffle(attackBag, new java.util.Random(random.nextLong()));
            // que el primero de la bolsa nueva no repita el ultimo ataque
            if (attackBag.get(attackBag.size() - 1) == lastAttack) Collections.swap(attackBag, 0, attackBag.size() - 1);
        }
        State next = attackBag.remove(attackBag.size() - 1);
        lastAttack = next;

        switch (next) {
            case FIRE -> setState(State.FIRE);
            case SPIRAL -> startSpiral(target);
            case CHARGE_WINDUP -> startCharge(sw);
            case HELL_CHARGE -> startHellfire(sw);
            default -> { }
        }
    }

    // =====================================================================
    //  ATAQUE 1: RAFAGA DE FUEGO
    // =====================================================================
    private void tickFire(ServerWorld sw, PlayerEntity target) {
        Vec3d flat = getPos().subtract(target.getPos());
        flat = new Vec3d(flat.x, 0, flat.z);
        Vec3d away = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1, 0, 0) : flat.normalize();
        Vec3d goal = target.getPos().add(away.multiply(FIRE_DISTANCE)).add(0, FIRE_HEIGHT, 0);
        steer(goal, 0.6, 0.08);

        Vec3d chest = target.getPos().add(0, target.getHeight() * 0.5, 0);
        aimBody(chest.subtract(getPos()), enraged() ? 9f : 6f, 0.12f);

        if (stateTicks == 1) playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 4.0f, 0.9f);

        Vec3d fwd = Vec3d.fromPolar(0f, getYaw());
        Vec3d mouth = getPos().add(fwd.multiply(2.4)).add(0, 1.6, 0);

        if (stateTicks < FIRE_WINDUP) {
            // carga: humo y chispas en la boca
            sw.spawnParticles(ParticleTypes.SMOKE, mouth.x, mouth.y, mouth.z, 3, 0.2, 0.2, 0.2, 0.01);
            sw.spawnParticles(ParticleTypes.FLAME, mouth.x, mouth.y, mouth.z, 1, 0.1, 0.1, 0.1, 0.01);
            return;
        }

        Vec3d aim = chest.subtract(mouth).normalize();
        spawnFlames(sw, mouth, aim);

        if (stateTicks % 5 == 0) {
            for (ServerPlayerEntity p : validPlayers(FIRE_RANGE + 4)) {
                Vec3d to = p.getPos().add(0, p.getHeight() * 0.5, 0).subtract(mouth);
                double dist = to.length();
                if (dist > FIRE_RANGE || dist < 1.0E-3) continue;
                if (to.normalize().dotProduct(aim) < FIRE_CONE_COS) continue;
                if (!hasClearLine(sw, mouth, p.getPos().add(0, p.getHeight() * 0.5, 0))) continue;
                p.setOnFireFor(FIRE_BURN_SECONDS);
                p.damage(getDamageSources().onFire(), FIRE_DAMAGE);
            }
        }

        int duration = enraged() ? FIRE_DURATION + 25 : FIRE_DURATION;
        if (stateTicks >= FIRE_WINDUP + duration) {
            recoverTicks = 20;
            setState(State.RECOVER);
        }
    }

    private void spawnFlames(ServerWorld sw, Vec3d mouth, Vec3d aim) {
        // chorros direccionales (count = 0 => delta se usa como velocidad)
        for (int i = 0; i < 4; i++) {
            Vec3d d = aim.add((random.nextDouble() - 0.5) * 0.12, (random.nextDouble() - 0.5) * 0.12, (random.nextDouble() - 0.5) * 0.12);
            sw.spawnParticles(ParticleTypes.FLAME, mouth.x, mouth.y, mouth.z, 0, d.x, d.y, d.z, 0.9);
        }
        // llamas a lo largo del cono para que se vea denso
        for (int d = 3; d <= 19; d += 4) {
            Vec3d p = mouth.add(aim.multiply(d));
            double spread = 0.25 + d * 0.05;
            sw.spawnParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, spread, spread, spread, 0.02);
            if (d > 10) sw.spawnParticles(ParticleTypes.SMOKE, p.x, p.y, p.z, 1, spread, spread, spread, 0.01);
        }
    }

    // =====================================================================
    //  ATAQUE 2: ESPIRAL + RAYOS + PICADA
    // =====================================================================
    private void startSpiral(PlayerEntity target) {
        spiralCenter = new Vec3d(target.getX(), 0, target.getZ());
        spiralStartY = getY();
        double dx = getX() - spiralCenter.x, dz = getZ() - spiralCenter.z;
        spiralAngle = Math.atan2(dz, dx);
        spiralR0 = Math.max(SPIRAL_RADIUS, Math.sqrt(dx * dx + dz * dz));
        setState(State.SPIRAL);
        playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 4.0f, 0.7f);
    }

    private void tickSpiral(ServerWorld sw) {
        float prog = Math.min(1f, stateTicks / 30f);
        double r = MathHelper.lerp(prog, spiralR0, SPIRAL_RADIUS);
        spiralAngle += SPIRAL_ANG_SPEED * (enraged() ? 1.15 : 1.0);
        double y = spiralStartY + Math.min(SPIRAL_HEIGHT, stateTicks * 0.30);

        Vec3d goal = new Vec3d(spiralCenter.x + Math.cos(spiralAngle) * r, y, spiralCenter.z + Math.sin(spiralAngle) * r);
        moveTo(goal, 0.8, 2.6);
        aimBody(getVelocity(), 30f, 0.25f);

        if (stateTicks >= 20 && stateTicks % LIGHTNING_INTERVAL == 0) {
            queueStrikes(sw);
        }
        if (stateTicks >= SPIRAL_TICKS) startDive(sw);
    }

    private void queueStrikes(ServerWorld sw) {
        List<ServerPlayerEntity> ps = validPlayers(70);
        if (ps.isEmpty()) return;
        int n = 1 + ps.size() / 3 + (enraged() ? 1 : 0);
        for (int i = 0; i < n; i++) {
            ServerPlayerEntity p = ps.get(random.nextInt(ps.size()));
            strikes.add(new Strike(p.getPos(), LIGHTNING_TELEGRAPH));
        }
    }

    /** Avanza los rayos pendientes (siguen cayendo aunque el ataque ya haya terminado). */
    private void tickStrikes(ServerWorld sw) {
        Iterator<Strike> it = strikes.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            if (s.left % 2 == 0) {
                for (int i = 0; i < 12; i++) {
                    double a = i * Math.PI / 6.0;
                    sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                            s.pos.x + Math.cos(a) * 2.5, s.pos.y + 0.1, s.pos.z + Math.sin(a) * 2.5,
                            1, 0, 0.1, 0, 0.02);
                }
            }
            if (--s.left <= 0) {
                strikeLightning(sw, s.pos);
                it.remove();
            }
        }
    }

    private void strikeLightning(ServerWorld sw, Vec3d pos) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(pos);
            sw.spawnEntity(bolt);
        }
        for (ServerPlayerEntity p : validPlayers(120)) {
            if (p.getPos().squaredDistanceTo(pos) <= LIGHTNING_EFFECT_RADIUS * LIGHTNING_EFFECT_RADIUS) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, LEVITATION_TICKS, LEVITATION_AMP));
            }
        }
    }

    private void startDive(ServerWorld sw) {
        List<ServerPlayerEntity> ps = validPlayers(80);
        Vec3d base = ps.isEmpty() ? spiralCenter : ps.get(random.nextInt(ps.size())).getPos();
        int gy = sw.getTopY(Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(base.x), MathHelper.floor(base.z));
        diveTarget = new Vec3d(base.x, gy + 1.0, base.z);
        setState(State.DIVE);
        playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 5.0f, 0.6f);
    }

    private void tickDive(ServerWorld sw) {
        Vec3d to = diveTarget.subtract(getPos());

        if (stateTicks < DIVE_HANG) {
            // se queda un instante apuntando hacia abajo (aviso)
            setVelocity(getVelocity().multiply(0.6));
            aimBody(to, 25f, 0.3f);
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1.0, getZ(), 6, 1.5, 0.8, 1.5, 0.05);
            return;
        }

        double spd = Math.min(3.2, 0.7 + (stateTicks - DIVE_HANG) * 0.22);
        Vec3d dir = to.normalize();
        setVelocity(dir.multiply(spd));
        aimBody(dir, 30f, 0.4f);
        sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 1.0, getZ(), 4, 0.8, 0.5, 0.8, 0.02);

        boolean arrived = to.lengthSquared() < 9.0 || getY() <= diveTarget.y + 0.5;
        if (arrived || verticalCollision || horizontalCollision || stateTicks > DIVE_HANG + 80) {
            slam(sw);
            recoverTicks = 50;
            setState(State.RECOVER);
        }
    }

    /** Impacto brutal: todos los jugadores a SLAM_RADIUS bloques o menos. */
    private void slam(ServerWorld sw) {
        Vec3d c = getPos();
        sw.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y + 0.5, c.z, 3, 2.0, 0.5, 2.0, 0.0);
        for (int k = 1; k <= 4; k++) {
            double radius = k * 5.0;
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI / 20.0;
                sw.spawnParticles(ParticleTypes.CLOUD, c.x + Math.cos(a) * radius, c.y + 0.3, c.z + Math.sin(a) * radius,
                        1, 0, 0.1, 0, 0.08);
                if (k <= 2) sw.spawnParticles(ParticleTypes.FLAME, c.x + Math.cos(a) * radius, c.y + 0.3, c.z + Math.sin(a) * radius,
                        1, 0, 0.1, 0, 0.05);
            }
        }
        sw.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.HOSTILE, 6.0f, 0.5f);
        sw.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.HOSTILE, 5.0f, 0.5f);

        for (ServerPlayerEntity p : validPlayers(SLAM_RADIUS)) {
            double dist = Math.sqrt(p.squaredDistanceTo(this));
            float t = (float) MathHelper.clamp(1.0 - dist / SLAM_RADIUS, 0.0, 1.0);
            float dmg = SLAM_DAMAGE_MIN + (SLAM_DAMAGE_MAX - SLAM_DAMAGE_MIN) * t;
            p.damage(getDamageSources().mobAttack(this), dmg);

            Vec3d out = new Vec3d(p.getX() - c.x, 0, p.getZ() - c.z);
            out = out.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 0) : out.normalize();
            p.setVelocity(out.x * 1.6, 0.9, out.z * 1.6);
            p.velocityModified = true;
        }
    }

    // =====================================================================
    //  ATAQUE 3: FURIA EMBESTIDA
    // =====================================================================
    private void startCharge(ServerWorld sw) {
        List<ServerPlayerEntity> ps = validPlayers(70);
        if (ps.isEmpty()) { setState(State.IDLE); return; }
        chargeTarget = ps.get(random.nextInt(ps.size()));
        chargeHit = false;
        setState(State.CHARGE_WINDUP);
        playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 5.0f, 1.2f);
    }

    private boolean chargeTargetValid() {
        return chargeTarget != null && chargeTarget.isAlive() && !chargeTarget.isCreative() && !chargeTarget.isSpectator();
    }

    private void tickChargeWindup(ServerWorld sw) {
        if (!chargeTargetValid()) { setState(State.IDLE); cooldown = 30; return; }

        Vec3d tpos = chargeTarget.getPos().add(0, chargeTarget.getHeight() * 0.5, 0);
        Vec3d flat = getPos().subtract(chargeTarget.getPos());
        flat = new Vec3d(flat.x, 0, flat.z);
        Vec3d away = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1, 0, 0) : flat.normalize();
        // retrocede para tomar carrera
        Vec3d goal = chargeTarget.getPos().add(away.multiply(26.0)).add(0, 5.0, 0);
        steer(goal, 0.7, 0.1);
        aimBody(tpos.subtract(getPos()), 20f, 0.2f);

        // aviso: chispas rojas sobre el objetivo
        sw.spawnParticles(ParticleTypes.ANGRY_VILLAGER, chargeTarget.getX(), chargeTarget.getY() + 2.4, chargeTarget.getZ(), 1, 0.3, 0.2, 0.3, 0.0);
        sw.spawnParticles(ParticleTypes.SMOKE, getX(), getY() + 1.4, getZ(), 3, 0.8, 0.4, 0.8, 0.02);

        if (stateTicks >= CHARGE_WINDUP) {
            chargeDir = tpos.subtract(getPos()).normalize();
            setState(State.CHARGE_DASH);
            playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 5.0f, 0.8f);
        }
    }

    private void tickChargeDash(ServerWorld sw) {
        // leve persecucion para que no sea imposible de esquivar
        if (chargeTargetValid() && !chargeHit) {
            Vec3d want = chargeTarget.getPos().add(0, chargeTarget.getHeight() * 0.5, 0).subtract(getPos()).normalize();
            chargeDir = chargeDir.lerp(want, 0.06).normalize();
        }
        double spd = enraged() ? CHARGE_SPEED + 0.4 : CHARGE_SPEED;
        setVelocity(chargeDir.multiply(spd));
        aimBody(chargeDir, 40f, 0.4f);
        sw.spawnParticles(ParticleTypes.FLAME, getX(), getY() + 1.2, getZ(), 6, 0.8, 0.5, 0.8, 0.03);
        sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 1.2, getZ(), 3, 0.8, 0.5, 0.8, 0.02);

        Box hit = getBoundingBox().expand(1.5, 1.0, 1.5);
        for (ServerPlayerEntity p : validPlayers(12)) {
            if (p.getBoundingBox().intersects(hit)) {
                chargeHitPlayer(sw, p);
            }
        }

        boolean ended = (chargeHit && stateTicks > 6) || stateTicks >= CHARGE_MAX_TICKS || horizontalCollision || verticalCollision;
        if (ended) {
            recoverTicks = chargeHit ? 25 : 35;
            setState(State.RECOVER);
        }
    }

    private void chargeHitPlayer(ServerWorld sw, ServerPlayerEntity p) {
        chargeHit = true;
        p.damage(getDamageSources().mobAttack(this), CHARGE_DAMAGE);
        Vec3d h = new Vec3d(chargeDir.x, 0, chargeDir.z);
        h = h.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 0) : h.normalize();
        p.setVelocity(h.x * CHARGE_KNOCKBACK, CHARGE_KNOCKBACK_Y, h.z * CHARGE_KNOCKBACK);
        p.velocityModified = true;
        sw.spawnParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY() + 1.0, p.getZ(), 4, 0.5, 0.5, 0.5, 0.0);
        sw.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.HOSTILE, 3.0f, 1.0f);
    }


    // =====================================================================
    //  ATAQUE 4: FUEGO INFERNAL (ignora Fire Resistance, explosion sin grief)
    // =====================================================================
    private static final int    HELL_CHARGE_TICKS = 60;    // 3 segundos cargando
    private static final int    HELL_LOCK_TICKS   = 48;    // a partir de aqui el rayo ya no sigue al jugador
    private static final int    HELL_BEAM_TICKS   = 12;
    private static final float  HELL_EXPLOSION_POWER = 2.0f;
    private static final double HELL_BLAST_RADIUS = 6.0;
    private static final int    HELL_BURN_TICKS   = 140;   // 7 s
    private static final float  HELL_BURN_DAMAGE  = 2.0f;  // cada 10 ticks, es dano magico (ignora Fire Resistance)

    private final List<ServerPlayerEntity> hellTargets = new ArrayList<>();
    private final List<Vec3d> hellAims = new ArrayList<>();
    private final List<Vec3d> hellEnds = new ArrayList<>();
    private Vec3d hellMouth = Vec3d.ZERO;
    private final Map<UUID, Integer> infernal = new HashMap<>();

    private Vec3d mouthPos() {
        return getPos().add(Vec3d.fromPolar(0f, getYaw()).multiply(2.4)).add(0, 1.6, 0);
    }

    private void startHellfire(ServerWorld sw) {
        List<ServerPlayerEntity> ps = validPlayers(80);
        if (ps.isEmpty()) { setState(State.IDLE); return; }
        Collections.shuffle(ps);
        int n = Math.min(ps.size(), 1 + (enraged() ? 1 : 0) + (ps.size() >= 4 ? 1 : 0));
        hellTargets.clear();
        hellTargets.addAll(ps.subList(0, n));
        hellAims.clear();
        hellEnds.clear();
        setState(State.HELL_CHARGE);
        playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 5.0f, 0.5f);
    }

    private void tickHellCharge(ServerWorld sw) {
        hellTargets.removeIf(p -> !p.isAlive() || p.isCreative() || p.isSpectator());
        if (hellTargets.isEmpty()) { cooldown = 30; setState(State.IDLE); return; }

        ServerPlayerEntity main = hellTargets.get(0);
        Vec3d flat = getPos().subtract(main.getPos());
        flat = new Vec3d(flat.x, 0, flat.z);
        Vec3d away = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1, 0, 0) : flat.normalize();
        steer(main.getPos().add(away.multiply(16.0)).add(0, 9.0, 0), 0.6, 0.08);

        Vec3d chest = main.getPos().add(0, main.getHeight() * 0.5, 0);
        if (stateTicks < HELL_LOCK_TICKS) aimBody(chest.subtract(getPos()), 8f, 0.15f);
        else setVelocity(getVelocity().multiply(0.8));

        Vec3d mouth = mouthPos();
        // carga: esfera de fuego infernal que se concentra en la boca
        sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, mouth.x, mouth.y, mouth.z, 2 + stateTicks / 5, 0.3, 0.3, 0.3, 0.02);
        double rr = 3.0 * (1.0 - stateTicks / (double) HELL_CHARGE_TICKS) + 0.3;
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0 + age * 0.3;
            sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, mouth.x + Math.cos(a) * rr, mouth.y + (random.nextDouble() - 0.5) * rr, mouth.z + Math.sin(a) * rr, 1, 0, 0, 0, 0.0);
        }
        // aviso de la zona de explosion sobre cada objetivo
        if (stateTicks % 4 == 0) {
            for (ServerPlayerEntity p : hellTargets) {
                for (int i = 0; i < 20; i++) {
                    double a = i * Math.PI / 10.0;
                    sw.spawnParticles(ParticleTypes.FLAME, p.getX() + Math.cos(a) * HELL_BLAST_RADIUS, p.getY() + 0.1, p.getZ() + Math.sin(a) * HELL_BLAST_RADIUS, 1, 0, 0.05, 0, 0.0);
                }
            }
        }

        if (stateTicks == HELL_LOCK_TICKS) {
            hellAims.clear();
            for (ServerPlayerEntity p : hellTargets) hellAims.add(p.getPos().add(0, p.getHeight() * 0.5, 0));
        }
        if (stateTicks >= HELL_CHARGE_TICKS) fireHellfire(sw);
    }

    private void fireHellfire(ServerWorld sw) {
        hellMouth = mouthPos();
        hellEnds.clear();
        playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 6.0f, 0.4f);

        for (Vec3d aim : hellAims) {
            Vec3d dir = aim.subtract(hellMouth).normalize();
            Vec3d far = hellMouth.add(dir.multiply(80.0));
            Vec3d end = sw.raycast(new RaycastContext(hellMouth, far, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, this)).getPos();
            hellEnds.add(end);

            // quien cruce el rayo se quema
            for (ServerPlayerEntity p : validPlayers(100)) {
                if (distToSegment(p.getPos().add(0, p.getHeight() * 0.5, 0), hellMouth, end) <= 1.8) igniteInfernal(p);
            }
            // explosion sin grief + fuego infernal en el area
            sw.createExplosion(null, end.x, end.y, end.z, HELL_EXPLOSION_POWER, false, World.ExplosionSourceType.NONE);
            sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, end.x, end.y + 0.5, end.z, 80, 2.5, 1.0, 2.5, 0.08);
            for (ServerPlayerEntity p : validPlayers(100)) {
                if (p.getPos().squaredDistanceTo(end) <= HELL_BLAST_RADIUS * HELL_BLAST_RADIUS) igniteInfernal(p);
            }
        }
        hellAims.clear();
        setState(State.HELL_BEAM);
    }

    private void tickHellBeam(ServerWorld sw) {
        setVelocity(getVelocity().multiply(0.7));
        for (Vec3d end : hellEnds) {
            Vec3d d = end.subtract(hellMouth);
            double len = d.length();
            if (len < 1.0E-3) continue;
            Vec3d step = d.multiply(1.0 / len);
            for (double t = 0; t < len; t += 1.0) {
                Vec3d p = hellMouth.add(step.multiply(t));
                sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 1, 0.1, 0.1, 0.1, 0.0);
                if (((int) t + stateTicks) % 3 == 0) sw.spawnParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 1, 0.15, 0.15, 0.15, 0.0);
            }
        }
        if (stateTicks >= HELL_BEAM_TICKS) {
            hellEnds.clear();
            recoverTicks = 25;
            setState(State.RECOVER);
        }
    }

    private void igniteInfernal(ServerPlayerEntity p) {
        infernal.put(p.getUuid(), HELL_BURN_TICKS);
    }

    /** Fuego infernal: dano magico periodico, ignora Fire Resistance. Se apaga entrando al agua. */
    private void tickInfernal(ServerWorld sw) {
        if (infernal.isEmpty()) return;
        Iterator<Map.Entry<UUID, Integer>> it = infernal.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            PlayerEntity p = sw.getPlayerByUuid(e.getKey());
            int left = e.getValue() - 1;
            if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator() || p.isTouchingWater() || left <= 0) {
                it.remove();
                continue;
            }
            e.setValue(left);
            sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1.0, p.getZ(), 3, 0.3, 0.5, 0.3, 0.02);
            if (left % 10 == 0) {
                p.setOnFireFor(3);
                p.damage(getDamageSources().indirectMagic(this, this), HELL_BURN_DAMAGE);
            }
        }
    }

    private static double distToSegment(Vec3d p, Vec3d a, Vec3d b) {
        Vec3d ab = b.subtract(a);
        double len2 = ab.lengthSquared();
        double t = len2 < 1.0E-6 ? 0.0 : MathHelper.clamp(p.subtract(a).dotProduct(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.multiply(t)));
    }

    // =====================================================================
    //  RECOVER: recupera altura y vuelve a IDLE
    // =====================================================================
    private void tickRecover(ServerWorld sw, PlayerEntity target) {
        Vec3d goal = new Vec3d(getX(), target.getY() + 11.0, getZ());
        steer(goal, 0.5, 0.1);
        aimBody(Vec3d.fromPolar(0f, getYaw()).add(0, getVelocity().y * 0.5, 0), 4f, 0.15f);
        if (stateTicks >= recoverTicks) {
            cooldown = enraged() ? 25 : 45;
            setState(State.IDLE);
        }
    }

    // =====================================================================
    //  Invocaciones: Drakil + Infernal BoxE
    //  Regla: no aparece una oleada nueva hasta que mueran TODOS los esbirros vivos.
    // =====================================================================
    private void checkSummonThresholds(ServerWorld sw) {
        float f = getHealth() / getMaxHealth();
        if (!summonedAt66 && f <= 0.66f) { summonedAt66 = true; pendingWaves++; }
        if (!summonedAt33 && f <= 0.33f) { summonedAt33 = true; pendingWaves++; }

        if (pendingWaves > 0 && aliveMinions(sw) == 0) {
            pendingWaves--;
            wavesSpawned++;
            summonMinions(sw, wavesSpawned);
        }
    }

    /** Cuenta esbirros vivos y limpia de la lista a los muertos / desaparecidos. */
    private int aliveMinions(ServerWorld sw) {
        if (minions.isEmpty()) return 0;
        minions.removeIf(id -> !(sw.getEntity(id) instanceof LivingEntity le) || !le.isAlive());
        return minions.size();
    }

    protected void summonMinions(ServerWorld sw, int wave) {
        List<ServerPlayerEntity> ps = validPlayers(90);
        if (ps.isEmpty()) { pendingWaves++; wavesSpawned--; return; }  // nadie cerca: reintenta luego

        int idx = MathHelper.clamp(wave - 1, 0, WAVE_DRAKIL.length - 1);
        int extra = ps.size() / 3;
        int nDrakil = WAVE_DRAKIL[idx] + extra;
        int nInfernal = WAVE_INFERNAL[idx] + extra;

        playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 6.0f, 0.6f);
        for (int i = 0; i < nDrakil; i++) spawnMinion(sw, ModEntities.DRAKIL.create(sw), ps, 0.0);
        for (int i = 0; i < nInfernal; i++) spawnMinion(sw, ModEntities.INFERNAL_BOXE.create(sw), ps, 3.0);
    }

    private void spawnMinion(ServerWorld sw, MobEntity mob, List<ServerPlayerEntity> ps, double extraY) {
        if (mob == null) return;
        ServerPlayerEntity p = ps.get(random.nextInt(ps.size()));

        double x = p.getX(), y = p.getY() + extraY, z = p.getZ();
        for (int attempt = 0; attempt < 12; attempt++) {
            double a = random.nextDouble() * Math.PI * 2;
            double r = MINION_RADIUS_MIN + random.nextDouble() * (MINION_RADIUS_MAX - MINION_RADIUS_MIN);
            double cx = p.getX() + Math.cos(a) * r, cz = p.getZ() + Math.sin(a) * r;
            mob.refreshPositionAndAngles(cx, p.getY() + extraY, cz, random.nextFloat() * 360f, 0f);
            if (sw.isSpaceEmpty(mob)) { x = cx; y = p.getY() + extraY; z = cz; break; }
        }
        mob.refreshPositionAndAngles(x, y, z, random.nextFloat() * 360f, 0f);
        mob.setPersistent();
        mob.setTarget(p);
        sw.spawnEntity(mob);
        minions.add(mob.getUuid());
        sw.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y + 1.0, z, 25, 0.5, 0.8, 0.5, 0.03);
        sw.spawnParticles(ParticleTypes.FLAME, x, y + 1.0, z, 20, 0.4, 0.8, 0.4, 0.05);
    }

    // ---- guardado ----
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Summoned66", summonedAt66);
        nbt.putBoolean("Summoned33", summonedAt33);
        nbt.putInt("PendingWaves", pendingWaves);
        nbt.putInt("WavesSpawned", wavesSpawned);
        NbtList list = new NbtList();
        for (UUID id : minions) list.add(NbtString.of(id.toString()));
        nbt.put("Minions", list);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        summonedAt66 = nbt.getBoolean("Summoned66");
        summonedAt33 = nbt.getBoolean("Summoned33");
        pendingWaves = nbt.getInt("PendingWaves");
        wavesSpawned = nbt.getInt("WavesSpawned");
        minions.clear();
        NbtList list = nbt.getList("Minions", NbtElement.STRING_TYPE);
        for (int i = 0; i < list.size(); i++) {
            try { minions.add(UUID.fromString(list.getString(i))); } catch (IllegalArgumentException ignored) { }
        }
    }

    // =====================================================================
    //  Utilidades de movimiento / objetivos
    // =====================================================================
    /** Movimiento suave hacia un punto (idle, fuego, recuperacion). */
    private void steer(Vec3d goal, double maxSpeed, double response) {
        Vec3d delta = goal.subtract(getPos());
        double dist = delta.length();
        Vec3d desired = dist < 1.0E-4 ? Vec3d.ZERO : delta.multiply(1.0 / dist).multiply(Math.min(maxSpeed, dist * 0.15));
        setVelocity(getVelocity().lerp(desired, response));
        if (horizontalCollision) setVelocity(getVelocity().add(0, 0.25, 0));
    }

    /** Movimiento directo (espiral): sigue un punto que se mueve rapido sin quedarse atras. */
    private void moveTo(Vec3d goal, double gain, double maxSpeed) {
        Vec3d d = goal.subtract(getPos()).multiply(gain);
        if (d.length() > maxSpeed) d = d.normalize().multiply(maxSpeed);
        setVelocity(d);
    }

    /** Orienta el yaw (con giro maximo por tick) y el pitch visual (grados, + = abajo). */
    private void aimBody(Vec3d dir, float maxYawStep, float pitchSmooth) {
        double h = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        if (h > 1.0E-3) {
            float ty = (float) (Math.atan2(dir.z, dir.x) * 180.0 / Math.PI) - 90.0f;
            setYaw(stepAngle(getYaw(), ty, maxYawStep));
        }
        float tp = (float) (-(Math.atan2(dir.y, h) * 180.0 / Math.PI));
        tp = MathHelper.clamp(tp, -80f, 80f);
        float cur = dataTracker.get(VIS_PITCH);
        dataTracker.set(VIS_PITCH, MathHelper.lerp(pitchSmooth, cur, tp));
    }

    /** Gira un angulo (grados) hacia otro con un maximo de giro por tick. */
    private static float stepAngle(float from, float to, float step) {
        float diff = MathHelper.wrapDegrees(to - from);
        return from + MathHelper.clamp(diff, -step, step);
    }

    private PlayerEntity pickTarget() {
        LivingEntity cur = getTarget();
        if (cur instanceof PlayerEntity p && p.isAlive() && !p.isCreative() && !p.isSpectator()
                && squaredDistanceTo(p) < 100.0 * 100.0) {
            return p;
        }
        PlayerEntity np = getWorld().getClosestPlayer(getX(), getY(), getZ(), 96.0, true);
        setTarget(np);
        return np;
    }

    private List<ServerPlayerEntity> validPlayers(double range) {
        List<ServerPlayerEntity> out = new ArrayList<>();
        if (getWorld() instanceof ServerWorld sw) {
            double r2 = range * range;
            for (ServerPlayerEntity p : sw.getPlayers()) {
                if (p.isAlive() && !p.isCreative() && !p.isSpectator() && p.squaredDistanceTo(this) <= r2) {
                    out.add(p);
                }
            }
        }
        return out;
    }

    private boolean hasClearLine(ServerWorld sw, Vec3d from, Vec3d to) {
        return sw.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, this)).getType() == HitResult.Type.MISS;
    }
}
