package com.dragonbar.entity;

import com.dragonbar.effect.RendEffect;
import com.dragonbar.registry.ModEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;

/**
 * Drakil: subdito del dragon (mitad humano, mitad dragon). Pelea cuerpo a cuerpo y de vez en cuando
 * vuela: orbita al jugador y se lanza en picada. Sus golpes aplican DESGARRO (sangrado).
 */
public class DrakilEntity extends HostileEntity implements GeoEntity {
    // ---- balance ----
    private static final int    FLIGHT_MIN_TICKS   = 90;
    private static final int    FLIGHT_RAND_TICKS  = 40;
    private static final int    SWOOP_TICKS        = 35;    // los ultimos ticks del vuelo baja en picada
    private static final int    FLIGHT_CD_MIN      = 160;   // espera entre vuelos
    private static final int    FLIGHT_CD_RAND     = 120;
    private static final double FLIGHT_HEIGHT      = 5.0;
    private static final double FLIGHT_RADIUS      = 7.0;

    private static final TrackedData<Boolean> FLYING =
            DataTracker.registerData(DrakilEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private int flightCooldown = 100;

    /** Cliente: 0..1 suavizado de "esta volando" (lo lee DrakilModel). */
    public float flyAmt, flyAmtO;

    public DrakilEntity(EntityType<? extends DrakilEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 10;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.31)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_ARMOR, 3.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FLYING, false);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new SwoopFlightGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.15, false));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 12.0f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    public boolean isFlying() { return dataTracker.get(FLYING); }

    private void setFlying(boolean f) {
        dataTracker.set(FLYING, f);
        setNoGravity(f);
        if (!f) fallDistance = 0f;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (flightCooldown > 0) flightCooldown--;
    }

    @Override
    public void tickMovement() {
        if (getWorld().isClient) {
            flyAmtO = flyAmt;
            flyAmt += ((isFlying() ? 1f : 0f) - flyAmt) * 0.15f;
        }
        super.tickMovement();
    }

    /** Cada golpe aplica Desgarro (dano seguido durante unos segundos). */
    @Override
    public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity le) {
            le.addStatusEffect(new StatusEffectInstance(ModEffects.REND, RendEffect.DURATION, 0), this);
        }
        return hit;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return super.isInvulnerableTo(source) || source.isOf(DamageTypes.FALL);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    // ---- GeckoLib (huesos por codigo en DrakilModel) ----
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) { }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return geoCache; }

    /** Vuelo ocasional: despega, orbita sobre el objetivo y baja en picada a golpearlo. */
    private static class SwoopFlightGoal extends Goal {
        private final DrakilEntity mob;
        private int ticks, attackCd;
        private double angle;

        SwoopFlightGoal(DrakilEntity mob) {
            this.mob = mob;
            setControls(EnumSet.of(Control.MOVE, Control.LOOK, Control.JUMP));
        }

        @Override public boolean canStart() {
            LivingEntity t = mob.getTarget();
            return t != null && t.isAlive() && mob.flightCooldown <= 0 && mob.isOnGround()
                    && mob.random.nextInt(40) == 0 && mob.squaredDistanceTo(t) > 25.0;
        }

        @Override public boolean shouldContinue() {
            LivingEntity t = mob.getTarget();
            return ticks > 0 && t != null && t.isAlive();
        }

        @Override public void start() {
            ticks = FLIGHT_MIN_TICKS + mob.random.nextInt(FLIGHT_RAND_TICKS);
            attackCd = 0;
            angle = mob.random.nextDouble() * Math.PI * 2;
            mob.setFlying(true);
            mob.setVelocity(mob.getVelocity().add(0, 0.6, 0));
            mob.getWorld().playSound(null, mob.getBlockPos(), SoundEvents.ENTITY_PHANTOM_FLAP,
                    SoundCategory.HOSTILE, 1.5f, 0.7f);
        }

        @Override public void stop() {
            mob.setFlying(false);
            mob.flightCooldown = FLIGHT_CD_MIN + mob.random.nextInt(FLIGHT_CD_RAND);
        }

        @Override public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) { ticks = 0; return; }
            ticks--;
            mob.getLookControl().lookAt(t, 40.0f, 40.0f);

            boolean swoop = ticks < SWOOP_TICKS;
            Vec3d goal;
            double maxSpeed;
            if (swoop) {
                goal = t.getPos().add(0, t.getHeight() * 0.5, 0);
                maxSpeed = 0.75;
            } else {
                angle += 0.09;
                goal = t.getPos().add(Math.cos(angle) * FLIGHT_RADIUS, FLIGHT_HEIGHT, Math.sin(angle) * FLIGHT_RADIUS);
                maxSpeed = 0.45;
            }
            Vec3d d = goal.subtract(mob.getPos());
            if (d.length() > maxSpeed) d = d.normalize().multiply(maxSpeed);
            mob.setVelocity(mob.getVelocity().lerp(d, 0.25));
            if (mob.horizontalCollision) mob.setVelocity(mob.getVelocity().add(0, 0.3, 0));

            if (attackCd > 0) attackCd--;
            if (swoop && attackCd == 0 && mob.getBoundingBox().expand(0.8).intersects(t.getBoundingBox())) {
                mob.swingHand(Hand.MAIN_HAND);
                mob.tryAttack(t);
                attackCd = 20;
                ticks = Math.min(ticks, 12); // despues del tajo se retira y aterriza
            }
        }
    }
}
