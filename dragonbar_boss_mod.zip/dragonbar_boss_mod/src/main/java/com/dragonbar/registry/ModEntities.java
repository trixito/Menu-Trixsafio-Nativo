package com.dragonbar.registry;

import com.dragonbar.DragonBarMod;
import com.dragonbar.entity.DragonBossEntity;
import com.dragonbar.entity.DrakilEntity;
import com.dragonbar.entity.InfernalBoxeEntity;
import com.dragonbar.entity.InfernalFireballEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    private ModEntities() {}

    // Omega Wyvern (el id interno sigue siendo dragon_oriental para no romper assets ni /summon)
    public static final EntityType<DragonBossEntity> DRAGON_ORIENTAL = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(DragonBarMod.MOD_ID, "dragon_oriental"),
            EntityType.Builder.create(DragonBossEntity::new, SpawnGroup.MONSTER)
                    .dimensions(3.0f, 2.2f)
                    .maxTrackingRange(10)
                    .trackingTickInterval(1)
                    .makeFireImmune()
                    .build("dragon_oriental"));

    public static final EntityType<DrakilEntity> DRAKIL = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(DragonBarMod.MOD_ID, "drakil"),
            EntityType.Builder.create(DrakilEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.7f, 2.2f)
                    .maxTrackingRange(8)
                    .build("drakil"));

    public static final EntityType<InfernalBoxeEntity> INFERNAL_BOXE = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(DragonBarMod.MOD_ID, "infernal_boxe"),
            EntityType.Builder.create(InfernalBoxeEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.8f, 1.8f)
                    .maxTrackingRange(8)
                    .makeFireImmune()
                    .build("infernal_boxe"));

    public static final EntityType<InfernalFireballEntity> INFERNAL_FIREBALL = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(DragonBarMod.MOD_ID, "infernal_fireball"),
            EntityType.Builder.<InfernalFireballEntity>create(InfernalFireballEntity::new, SpawnGroup.MISC)
                    .dimensions(0.5f, 0.5f)
                    .maxTrackingRange(4)
                    .trackingTickInterval(10)
                    .makeFireImmune()
                    .build("infernal_fireball"));

    public static void register() {
        FabricDefaultAttributeRegistry.register(DRAGON_ORIENTAL, DragonBossEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DRAKIL, DrakilEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(INFERNAL_BOXE, InfernalBoxeEntity.createAttributes());
    }
}
