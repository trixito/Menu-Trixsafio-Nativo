package com.dragonbar.registry;

import com.dragonbar.DragonBarMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    private ModItems() {}

    public static final Item DRAGON_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            Identifier.of(DragonBarMod.MOD_ID, "dragon_oriental_spawn_egg"),
            new SpawnEggItem(ModEntities.DRAGON_ORIENTAL, 0x1E7A3C, 0xF2C230, new Item.Settings()));

    public static final Item DRAKIL_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            Identifier.of(DragonBarMod.MOD_ID, "drakil_spawn_egg"),
            new SpawnEggItem(ModEntities.DRAKIL, 0x2F6B3A, 0x8E1B1B, new Item.Settings()));

    public static final Item INFERNAL_BOXE_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            Identifier.of(DragonBarMod.MOD_ID, "infernal_boxe_spawn_egg"),
            new SpawnEggItem(ModEntities.INFERNAL_BOXE, 0xB8330C, 0xFFB000, new Item.Settings()));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(DRAGON_SPAWN_EGG);
            entries.add(DRAKIL_SPAWN_EGG);
            entries.add(INFERNAL_BOXE_SPAWN_EGG);
        });
    }
}
