package com.dragonbar.registry;

import com.dragonbar.DragonBarMod;
import com.dragonbar.effect.RendEffect;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public final class ModEffects {
    private ModEffects() {}

    public static final RegistryEntry<StatusEffect> REND = Registry.registerReference(
            Registries.STATUS_EFFECT, Identifier.of(DragonBarMod.MOD_ID, "rend"), new RendEffect());

    public static void register() { /* fuerza la carga de la clase */ }
}
