package com.dragonbar.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.UUID;

@Mixin(BossBarHud.class)
public abstract class BossBarHudMixin {
    @Shadow @Final Map<UUID, ClientBossBar> bossBars;

    private static final Identifier DRAGON_BACK  = Identifier.of("dragonbar", "textures/gui/dragon_back.png");
    private static final Identifier DRAGON_FRONT = Identifier.of("dragonbar", "textures/gui/dragon_front.png");
    private static final int TEX_W = 320, TEX_H = 56, BAR_X = 69, BAR_Y = 26, SHIFT_Y = 16;

    // Capa de atras: se dibuja ANTES de la barra vanilla
    @Inject(method = "render", at = @At("HEAD"))
    private void dragonbar$back(DrawContext ctx, CallbackInfo ci) {
        if (bossBars.isEmpty()) return;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(0, SHIFT_Y, 0);
        dragonbar$draw(ctx, DRAGON_BACK);
    }

    // Capa de adelante (garras, bigotes, perla, cruces del cuerpo): DESPUES de la barra
    @Inject(method = "render", at = @At("RETURN"))
    private void dragonbar$front(DrawContext ctx, CallbackInfo ci) {
        if (bossBars.isEmpty()) return;
        dragonbar$draw(ctx, DRAGON_FRONT);
        ctx.getMatrices().pop();
    }

    private void dragonbar$draw(DrawContext ctx, Identifier tex) {
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        int i = 0;
        RenderSystem.enableBlend();
        for (ClientBossBar bar : bossBars.values()) {
            int y = 12 + i * 19;                       // y vanilla de la barra
            if (y >= h / 3) break;
            if (bar.getColor() == BossBar.Color.GREEN) // solo las barras verdes llevan dragon
                ctx.drawTexture(tex, w / 2 - 91 - BAR_X, y - BAR_Y, 0, 0, TEX_W, TEX_H, TEX_W, TEX_H);
            i++;
        }
        RenderSystem.disableBlend();
    }
}
