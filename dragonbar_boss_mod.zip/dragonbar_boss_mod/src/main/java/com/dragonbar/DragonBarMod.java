package com.dragonbar;

import com.dragonbar.registry.ModEffects;
import com.dragonbar.registry.ModEntities;
import com.dragonbar.registry.ModItems;
import net.fabricmc.api.ModInitializer;

public class DragonBarMod implements ModInitializer {
    public static final String MOD_ID = "dragonbar";

    @Override
    public void onInitialize() {
        ModEffects.register();
        ModEntities.register();
        ModItems.register();
    }
}
