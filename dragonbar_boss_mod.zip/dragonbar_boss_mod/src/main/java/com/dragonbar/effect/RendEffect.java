package com.dragonbar.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;

/** Desgarro: sangrado. Dano periodico durante unos segundos (lo aplican los Drakil al golpear). */
public class RendEffect extends StatusEffect {
    public static final float DAMAGE = 2.0f;      // por tick de sangrado
    public static final int   INTERVAL = 20;      // ticks entre cada dano (1 s)
    public static final int   DURATION = 120;     // 6 s => 6 danos

    public RendEffect() {
        super(StatusEffectCategory.HARMFUL, 0x9B0F0F);
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        int k = Math.max(1, INTERVAL >> amplifier);
        return duration % k == 0;
    }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        entity.damage(entity.getDamageSources().magic(), DAMAGE);
        if (entity.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, entity.getX(), entity.getBodyY(0.6), entity.getZ(),
                    3, 0.25, 0.3, 0.25, 0.1);
        }
        return true;
    }
}
