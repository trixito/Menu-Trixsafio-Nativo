package com.trixsafio.menus;

/** Ajustes rápidos del mod. Edita aquí y vuelve a compilar. */
public final class TrixConfig {
    private TrixConfig() {}

    /** IP del servidor al que entra el botón "Entrar a TrixSafio". */
    public static final String SERVER_IP = "TU_IP_AQUI";
    public static final String SERVER_NAME = "TrixSafio";

    // Tamaño real de las texturas (ver assets/trixsafio_menus/textures/gui)
    public static final int LOGO_W = 1673, LOGO_H = 624;
    public static final int BG_W = 1920, BG_H = 1440;

    // Menú de inicio (proporciones de la pantalla)
    public static final float TITLE_CENTER_X = 0.363f; // centro horizontal del logo y botones
    public static final float TITLE_LOGO_WIDTH = 0.34f;
    public static final float TITLE_LOGO_Y = 0.04f;
    public static final float[] TITLE_BTN_Y = {0.56f, 0.66f, 0.76f};

    // Menú de pausa
    public static final float PAUSE_CENTER_X = 0.5f;
    public static final float PAUSE_LOGO_WIDTH = 0.38f;
    public static final float PAUSE_LOGO_Y = 0.04f;
    public static final float[] PAUSE_BTN_Y = {0.547f, 0.658f, 0.756f};

    public static final float TEXT_SCALE = 1.5f;

    // Colores de los botones del inicio
    public static final int COLOR_ENTRAR = 0xFF5555;
    public static final int COLOR_CONFIG = 0xFFCC00;
    public static final int COLOR_SALIR = 0x55FF55;
    public static final int COLOR_WHITE = 0xFFFFFF;
}
