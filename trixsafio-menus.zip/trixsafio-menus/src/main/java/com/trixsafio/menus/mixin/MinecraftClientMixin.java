package com.trixsafio.menus.mixin;

import com.trixsafio.menus.TrixPauseScreen;
import com.trixsafio.menus.TrixTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    // Intercepta cualquier cambio de pantalla y cambia la vanilla por la nuestra.
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen trixsafio$replaceScreen(Screen screen) {
        if (screen != null) {
            if (screen.getClass() == TitleScreen.class) {
                return new TrixTitleScreen();
            }
            if (screen.getClass() == GameMenuScreen.class) {
                return new TrixPauseScreen();
            }
        }
        return screen;
    }
}
