package com.trixsafio.menus;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConnectScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class TrixTitleScreen extends Screen {
    public static final Identifier LOGO = Identifier.of("trixsafio_menus", "textures/gui/logo.png");
    public static final Identifier BACKGROUND = Identifier.of("trixsafio_menus", "textures/gui/background.png");

    public TrixTitleScreen() {
        super(Text.literal("TrixSafio"));
    }

    @Override
    protected void init() {
        int cx = (int) (width * TrixConfig.TITLE_CENTER_X);
        float[] y = TrixConfig.TITLE_BTN_Y;
        float sc = TrixConfig.TEXT_SCALE;

        addDrawableChild(new TextButton(cx, (int) (height * y[0]), sc,
                Text.literal("Entrar a " + TrixConfig.SERVER_NAME), TrixConfig.COLOR_ENTRAR, this::joinServer));
        addDrawableChild(new TextButton(cx, (int) (height * y[1]), sc,
                Text.literal("Configuración"), TrixConfig.COLOR_CONFIG,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(new TextButton(cx, (int) (height * y[2]), sc,
                Text.literal("Salir"), TrixConfig.COLOR_SALIR, () -> client.scheduleStop()));
    }

    private void joinServer() {
        ServerInfo info = new ServerInfo(TrixConfig.SERVER_NAME, TrixConfig.SERVER_IP, ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(this, MinecraftClient.getInstance(),
                ServerAddress.parse(TrixConfig.SERVER_IP), info, false, null);
    }

    /** Fondo a pantalla completa (modo "cover": llena sin deformar). Sin blur. */
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        float scale = Math.max((float) width / TrixConfig.BG_W, (float) height / TrixConfig.BG_H);
        int regionW = Math.round(width / scale);
        int regionH = Math.round(height / scale);
        float u = (TrixConfig.BG_W - regionW) / 2f;
        float v = (TrixConfig.BG_H - regionH) / 2f;
        context.drawTexture(BACKGROUND, 0, 0, width, height, u, v, regionW, regionH, TrixConfig.BG_W, TrixConfig.BG_H);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta); // fondo + botones

        int logoW = (int) (width * TrixConfig.TITLE_LOGO_WIDTH);
        int logoH = logoW * TrixConfig.LOGO_H / TrixConfig.LOGO_W;
        int logoX = (int) (width * TrixConfig.TITLE_CENTER_X) - logoW / 2;
        int logoY = (int) (height * TrixConfig.TITLE_LOGO_Y);
        context.drawTexture(LOGO, logoX, logoY, logoW, logoH, 0f, 0f,
                TrixConfig.LOGO_W, TrixConfig.LOGO_H, TrixConfig.LOGO_W, TrixConfig.LOGO_H);

        String version = "Minecraft " + client.getGameVersion() + "/Fabric (Modded)";
        context.drawTextWithShadow(textRenderer, version, 2, height - 10, 0xFFFFFFFF);
        String copy = "Copyright Mojang AB. Do not distribute!";
        context.drawTextWithShadow(textRenderer, copy, width - textRenderer.getWidth(copy) - 2, height - 10, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
