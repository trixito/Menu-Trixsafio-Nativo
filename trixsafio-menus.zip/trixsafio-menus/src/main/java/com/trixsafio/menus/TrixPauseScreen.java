package com.trixsafio.menus;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

public class TrixPauseScreen extends Screen {

    public TrixPauseScreen() {
        super(Text.literal("Pausa"));
    }

    @Override
    protected void init() {
        int cx = (int) (width * TrixConfig.PAUSE_CENTER_X);
        float[] y = TrixConfig.PAUSE_BTN_Y;
        float sc = TrixConfig.TEXT_SCALE;

        addDrawableChild(new TextButton(cx, (int) (height * y[0]), sc,
                Text.literal("Regresar al Juego"), TrixConfig.COLOR_WHITE, () -> {
                    client.setScreen(null);
                    client.mouse.lockCursor();
                }));
        addDrawableChild(new TextButton(cx, (int) (height * y[1]), sc,
                Text.literal("Opciones"), TrixConfig.COLOR_WHITE,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(new TextButton(cx, (int) (height * y[2]), sc,
                Text.literal("Salir al Menu"), TrixConfig.COLOR_WHITE, this::disconnect));
    }

    private void disconnect() {
        boolean singleplayer = client.isInSingleplayer();
        if (client.world != null) {
            client.world.disconnect();
        }
        if (singleplayer) {
            client.disconnect(new MessageScreen(Text.translatable("menu.savingLevel")));
        } else {
            client.disconnect();
        }
        client.setScreen(new TitleScreen()); // el mixin lo cambia por TrixTitleScreen
    }

    // Fondo: el blur vanilla del mundo (no se sobreescribe renderBackground).

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int logoW = (int) (width * TrixConfig.PAUSE_LOGO_WIDTH);
        int logoH = logoW * TrixConfig.LOGO_H / TrixConfig.LOGO_W;
        int logoX = (int) (width * TrixConfig.PAUSE_CENTER_X) - logoW / 2;
        int logoY = (int) (height * TrixConfig.PAUSE_LOGO_Y);
        context.drawTexture(TrixTitleScreen.LOGO, logoX, logoY, logoW, logoH, 0f, 0f,
                TrixConfig.LOGO_W, TrixConfig.LOGO_H, TrixConfig.LOGO_W, TrixConfig.LOGO_H);

        String credit = "Desarrollado por Gustambo Studios.";
        context.drawTextWithShadow(textRenderer, credit, width - textRenderer.getWidth(credit) - 4, height - 12, 0xFFFFFFFF);
    }
}
