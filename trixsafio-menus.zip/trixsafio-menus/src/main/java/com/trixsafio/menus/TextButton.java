package com.trixsafio.menus;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

/** Botón sin fondo: solo texto de color que se agranda y aclara al pasar el cursor. */
public class TextButton extends ClickableWidget {
    private final int color;
    private final float scale;
    private final Runnable action;

    public TextButton(int centerX, int centerY, float scale, Text label, int color, Runnable action) {
        super(0, 0, 10, 10, label);
        this.color = color;
        this.scale = scale;
        this.action = action;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int w = (int) (tr.getWidth(label) * scale) + 24;
        int h = (int) (9 * scale) + 12;
        setWidth(w);
        setHeight(h);
        setX(centerX - w / 2);
        setY(centerY - h / 2);
    }

    @Override
    public void onClick(double mouseX, double mouseY) {
        action.run();
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        boolean hover = isHovered();
        float s = scale * (hover ? 1.12f : 1.0f);
        int col = hover ? mix(color, 0xFFFFFF, 0.4f) : color;

        MatrixStack m = context.getMatrices();
        m.push();
        m.translate(getX() + getWidth() / 2f, getY() + getHeight() / 2f, 0);
        m.scale(s, s, 1f);
        context.drawCenteredTextWithShadow(tr, getMessage(), 0, -4, 0xFF000000 | col);
        m.pop();
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
