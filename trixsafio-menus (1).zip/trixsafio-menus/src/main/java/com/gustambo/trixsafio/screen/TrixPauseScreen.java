package com.gustambo.trixsafio.screen;

import com.gustambo.trixsafio.TrixConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

/** Menú de pausa: sin fondo propio (se ve el juego desenfocado) + logo + 3 textos. */
public class TrixPauseScreen extends Screen {
    public TrixPauseScreen() {
        super(Text.literal("Pausa"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int bw = 220, bh = 28;
        float scale = 1.8f;

        addDrawableChild(new TextMenuButton(cx, (int) (height * 0.55), bw, bh,
                Text.literal("Regresar al Juego"), TrixConfig.WHITE, scale, () -> client.setScreen(null)));
        addDrawableChild(new TextMenuButton(cx, (int) (height * 0.65), bw, bh,
                Text.literal("Opciones"), TrixConfig.WHITE, scale,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(new TextMenuButton(cx, (int) (height * 0.75), bw, bh,
                Text.literal("Salir al Menu"), TrixConfig.WHITE, scale, this::disconnect));
    }

    private void disconnect() {
        MinecraftClient mc = this.client;
        boolean singleplayer = mc.isInSingleplayer();
        if (mc.world != null) mc.world.disconnect();
        if (singleplayer) {
            mc.disconnect(new MessageScreen(Text.translatable("menu.savingLevel")));
        } else {
            mc.disconnect();
        }
        TitleScreen title = new TitleScreen(); // el mixin lo cambia por TrixTitleScreen
        if (singleplayer) mc.setScreen(title);
        else mc.setScreen(new MultiplayerScreen(title));
    }

    // Sin renderBackground propio: se usa el de vanilla (desenfoque + oscurecido del mundo).

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TrixLayout.drawLogo(ctx, width, height);
        ctx.drawTextWithShadow(textRenderer, TrixConfig.CREDITS,
                width - textRenderer.getWidth(TrixConfig.CREDITS) - 4, height - 11, 0xFFFFFFFF);
    }
}
