package com.gustambo.trixsafio.screen;

import com.gustambo.trixsafio.TrixConfig;
import net.minecraft.client.gui.DrawContext;

final class TrixLayout {
    private TrixLayout() {}

    static void drawLogo(DrawContext ctx, int width, int height) {
        double aspect = (double) TrixConfig.LOGO_W / TrixConfig.LOGO_H;
        int lw = (int) Math.min(width * 0.40, height * 0.40 * aspect);
        int lh = (int) (lw / aspect);
        int x = (width - lw) / 2;
        int y = (int) (height * 0.05);
        ctx.drawTexture(TrixConfig.LOGO, x, y, lw, lh, 0, 0,
                TrixConfig.LOGO_W, TrixConfig.LOGO_H, TrixConfig.LOGO_W, TrixConfig.LOGO_H);
    }
}
