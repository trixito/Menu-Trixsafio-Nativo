package com.gustambo.trixsafio.screen;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

/** Botón sin fondo: solo texto de color que crece y se ilumina al pasar el ratón. */
public class TextMenuButton extends ClickableWidget {
    private final int color;
    private final float scale;
    private final Runnable action;

    public TextMenuButton(int centerX, int centerY, int width, int height, Text text, int color, float scale, Runnable action) {
        super(centerX - width / 2, centerY - height / 2, width, height, text);
        this.color = color;
        this.scale = scale;
        this.action = action;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        boolean hov = this.isHovered();
        float s = hov ? scale * 1.12f : scale;
        int c = hov ? brighten(color) : color;

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(getX() + getWidth() / 2f, getY() + getHeight() / 2f, 0);
        m.scale(s, s, 1f);
        int tw = tr.getWidth(getMessage());
        ctx.drawText(tr, getMessage(), -tw / 2, -tr.fontHeight / 2, 0xFF000000 | c, true);
        m.pop();
    }

    private static int brighten(int rgb) {
        int r = Math.min(255, ((rgb >> 16) & 0xFF) + 70);
        int g = Math.min(255, ((rgb >> 8) & 0xFF) + 70);
        int b = Math.min(255, (rgb & 0xFF) + 70);
        return (r << 16) | (g << 8) | b;
    }

    @Override
    public void onClick(double mouseX, double mouseY) {
        action.run();
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        this.appendDefaultNarrations(builder);
    }
}
