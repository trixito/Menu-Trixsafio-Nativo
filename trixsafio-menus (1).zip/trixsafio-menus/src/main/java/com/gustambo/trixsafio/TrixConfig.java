package com.gustambo.trixsafio;

import net.minecraft.util.Identifier;

public final class TrixConfig {
    private TrixConfig() {}

    /** IP del servidor al que entra el botón "Entrar a TrixSafio". Si está vacía abre la lista de servidores. */
    public static final String SERVER_ADDRESS = "";
    public static final String SERVER_NAME = "TrixSafio";

    public static final String CREDITS = "Desarrollado por Gustambo Studios.";

    // Colores (RGB) de los botones de texto
    public static final int RED = 0xFF5555;
    public static final int YELLOW = 0xFFD700;
    public static final int GREEN = 0x55FF55;
    public static final int WHITE = 0xFFFFFF;

    public static final Identifier LOGO = Identifier.of("trixsafio_menus", "textures/gui/logo.png");
    public static final Identifier BACKGROUND = Identifier.of("trixsafio_menus", "textures/gui/background.png");
    public static final int LOGO_W = 1673, LOGO_H = 624;
    public static final int BG_W = 1920, BG_H = 1440;
}
