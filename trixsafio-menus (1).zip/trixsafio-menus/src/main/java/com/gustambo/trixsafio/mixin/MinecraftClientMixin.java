package com.gustambo.trixsafio.mixin;

import com.gustambo.trixsafio.screen.TrixPauseScreen;
import com.gustambo.trixsafio.screen.TrixTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen trixsafio$replaceScreen(Screen screen) {
        if (screen != null) {
            if (screen.getClass() == TitleScreen.class) return new TrixTitleScreen();
            if (screen.getClass() == GameMenuScreen.class) return new TrixPauseScreen();
        }
        return screen;
    }
}
