package com.gustambo.trixsafio.screen;

import com.gustambo.trixsafio.TrixConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;

public class TrixTitleScreen extends Screen {
    public TrixTitleScreen() {
        super(Text.literal("TrixSafio"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int bw = 220, bh = 28;
        float scale = 1.8f;

        addDrawableChild(new TextMenuButton(cx, (int) (height * 0.55), bw, bh,
                Text.literal("Entrar a TrixSafio"), TrixConfig.RED, scale, this::joinServer));
        addDrawableChild(new TextMenuButton(cx, (int) (height * 0.65), bw, bh,
                Text.literal("Configuración"), TrixConfig.YELLOW, scale,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(new TextMenuButton(cx, (int) (height * 0.75), bw, bh,
                Text.literal("Salir"), TrixConfig.GREEN, scale, () -> client.scheduleStop()));
    }

    private void joinServer() {
        String ip = TrixConfig.SERVER_ADDRESS;
        if (ip == null || ip.isBlank()) {
            client.setScreen(new MultiplayerScreen(this));
            return;
        }
        ServerInfo info = new ServerInfo(TrixConfig.SERVER_NAME, ip, ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(this, client, ServerAddress.parse(ip), info, false, null);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Fondo "cover": llena la pantalla sin deformar la imagen.
        double sc = Math.max((double) width / TrixConfig.BG_W, (double) height / TrixConfig.BG_H);
        int dw = (int) Math.ceil(TrixConfig.BG_W * sc);
        int dh = (int) Math.ceil(TrixConfig.BG_H * sc);
        int dx = (width - dw) / 2;
        int dy = (height - dh) / 2;
        ctx.drawTexture(TrixConfig.BACKGROUND, dx, dy, dw, dh, 0, 0,
                TrixConfig.BG_W, TrixConfig.BG_H, TrixConfig.BG_W, TrixConfig.BG_H);
        ctx.fill(0, 0, width, height, 0x33000000); // oscurece un poco para que se lea el texto
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TrixLayout.drawLogo(ctx, width, height);
        ctx.drawTextWithShadow(textRenderer, "Minecraft 1.21.1 / Fabric (Modded)", 4, height - 11, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, TrixConfig.CREDITS,
                width - textRenderer.getWidth(TrixConfig.CREDITS) - 4, height - 11, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
