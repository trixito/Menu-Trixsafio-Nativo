# TrixSafio Menus (Fabric 1.21.1)

Compilar (necesitas JDK 21):
    gradle wrapper --gradle-version 8.10   # solo la primera vez
    ./gradlew build                        # (en Windows: gradlew.bat build)
El .jar queda en build/libs/trixsafio-menus-1.0.0.jar

IP del servidor: src/main/java/com/gustambo/trixsafio/TrixConfig.java -> SERVER_ADDRESS
